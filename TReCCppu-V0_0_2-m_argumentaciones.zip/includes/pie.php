<?php
echo '
<div id="pie">
<h4>
-2014-
</h4>
<h4>
sitio desarrollado por
<a href="http://www.trecc.com.ar" target="_blank">TReCC S.A.</a>
e implementado para el programa de desarrollo de San Antonio Oeste
</h4>';


if($_SESSION['modo']!='html'){
echo "<h3>este sitio utiliza las siguientes tecnolog�as para operar:</h3>";
}else{
echo "<h3>este sitio utiliz� las siguientes tecnolog�as para su desarrollo:</h3>";	
}

echo '
<a target="_blank" href="http://www.gnu.org/" class="tec" title="sistema operativo del servidor">GNU linux</a>
<a target="_blank" href="https://httpd.apache.org/" class="tec" title="servidor HTTP">APACHE</a>
<a target="_blank"  href="http://www.mysql.com/" class="tec" title="base de datos">MySQL</a>
<a target="_blank"  href="http://www.postgresql.org/" class="tec" title="base de datos">PostgreSQL</a>
<a target="_blank"  href="http://postgis.net/" class="tec" title="base de datos geogr�fica">PostGIS</a>
<a target="_blank"  href="http://php.net/" class="tec" title="lenguaje de programaci�n del sitio">PHP</a>
<a target="_blank"  href="http://openlayers.org/" class="tec" title="librer�a Javasript para mapas">Openlayers</a>
<a target="_blank"  href="http://www.tinymce.com/" class="tec" title="editor de texto integrado en Javasript">TinyMCE</a> 
<a target="_blank"  href="http://www.google.com/fonts/specimen/Ropa+Sans" class="tec" title="tipograf�as">Google Web Fonts</a>
<a target="_blank"  href="http://www.baseobra.com.ar/" class="tec" title="plataforma de construcci�n colectiva de conocimiento t�cnico">baseobra</a>
<a target="_blank"  href="http://www.trecc.com.ar/" class="tec" title="plataforma de seguimiento de sistemas de indicadores">TReCC(tm) Panel de Control</a>
<h4>El c�digo de programaci�n de este sitio se encuentra publicado bajo licencia AGPL GNU / software libre <a href="http://www.trecc.com.ar/recursos/proyectoppu.htm">ver sitio del proyecto y descargas</a></h4> 
</div>
';
?>
