	<META http-equiv="Content-Type" content="text/html; charset=windows-1252">
 