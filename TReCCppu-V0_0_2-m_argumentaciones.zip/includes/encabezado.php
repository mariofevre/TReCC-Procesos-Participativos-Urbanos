<?php
if(isset($USUARIO['id'])){
echo "<div class='recuadro' id='recuadro1'>";
echo "<p>hola: ".$USUARIO['nombre']." ".$USUARIO['apellido']."</p>";
echo "<br>";
echo "<a class='boton' href='./login.php'>cerrar sesi�n</a>";
echo "</div>";
}
?>
